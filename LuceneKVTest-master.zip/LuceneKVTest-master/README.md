use lucene to as a KV storage, tried several kinds of lucene index and storage solutions .

[基于lucene的内嵌入kv存储] (http://3dobe.com/archives/247/)
